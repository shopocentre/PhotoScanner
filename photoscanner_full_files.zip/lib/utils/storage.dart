import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Storage {
  static Future<void> saveScan(String path) async {
    final dir = await getApplicationDocumentsDirectory();
    final fileName = basename(path);
    final newPath = join(dir.path, fileName);
    await File(path).copy(newPath);
    final prefs = await SharedPreferences.getInstance();
    List<String> scans = prefs.getStringList('scans') ?? [];
    scans.add(newPath);
    await prefs.setStringList('scans', scans);
  }

  static Future<List<String>> loadScans() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('scans') ?? [];
  }
}
