import 'package:image/image.dart' as img;
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';

class ImageProcessing {
  static Future<String> autoEnhance(String path) async {
    final file = File(path);
    final bytes = await file.readAsBytes();
    img.Image? image = img.decodeImage(bytes);
    if (image == null) return path;
    final enhanced = img.adjustColor(image, contrast: 1.2, brightness: 10);
    final dir = await getTemporaryDirectory();
    final newPath = join(dir.path, 'enhanced_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await File(newPath).writeAsBytes(img.encodeJpg(enhanced));
    return newPath;
  }
}
