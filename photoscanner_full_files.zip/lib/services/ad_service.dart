import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdService {
  static Future<void> initialize() async {
    await MobileAds.instance.initialize();
  }

  static BannerAd bannerAd() => BannerAd(
        adUnitId: 'ca-app-pub-xxxxxxxxxxxxxxxx/banner',
        size: AdSize.banner,
        request: const AdRequest(),
        listener: const BannerAdListener(),
      );
}
