import 'package:flutter/material.dart';
import '../utils/storage.dart';
import 'dart:io';

class ViewerScreen extends StatefulWidget {
  const ViewerScreen({super.key});
  @override
  State<ViewerScreen> createState() => _ViewerScreenState();
}

class _ViewerScreenState extends State<ViewerScreen> {
  List<String> scans = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    scans = await Storage.loadScans();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Scanned Documents')),
      body: scans.isEmpty
          ? const Center(child: Text('No scans yet'))
          : ListView.builder(
              itemCount: scans.length,
              itemBuilder: (context, index) {
                return Card(
                  child: ListTile(
                    leading: Image.file(File(scans[index]), width: 56, height: 56, fit: BoxFit.cover),
                    title: Text('Scan ${index + 1}'),
                  ),
                );
              },
            ),
    );
  }
}
